# Proyecto 1: Librería Triple Peaks

La página web de la Librería Triple Peaks es el primer proyecto en el programa de Ingeniería de software en Triple Ten. Fue creado utilizando HTML y CSS, con base en un informe de diseño.

## Características del proyecto

-	HTML5 semántico
-	Flexbox
-	Posicionamiento
-	Apilamiento vertical con z-index
